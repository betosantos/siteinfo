@extends('layouts.admin')

@section('content')


<div class="row">

  <!-- 3 colunas na tela
  <div class="col-md-4 col-sm-4 col-xs-12">
    <div class="x_panel tile fixed_height_320">
    </div>
  </div> -->

  <div class="col-md-12 col-sm-4 col-xs-12">
    <div class="x_panel tile fixed_height_320">


    </div>
  </div>


</div>

@endsection
