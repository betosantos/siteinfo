<?php $__env->startSection('content'); ?>


<div class="row">

  <!-- 3 colunas na tela
  <div class="col-md-4 col-sm-4 col-xs-12">
    <div class="x_panel tile fixed_height_320">
    </div>
  </div> -->

  <div class="col-md-12 col-sm-4 col-xs-12">
    <div class="x_panel tile fixed_height_320">


    </div>
  </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>