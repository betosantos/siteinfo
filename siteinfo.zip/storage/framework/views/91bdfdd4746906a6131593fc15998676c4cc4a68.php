<?php $__env->startSection('content'); ?>


<div class="row">

  <!-- 3 colunas na tela
  <div class="col-md-4 col-sm-4 col-xs-12">
  <div class="x_panel tile fixed_height_320">
</div>
</div> -->

<div class="col-md-12 col-sm-4 col-xs-12">
  <h3>Posts Cadastrados</h3>

  <table class="table">
    <thead>
      <tr>
        <th scope="col">Imagem</th>
        <th scope="col">Título</th>
        <th scope="col">Descrição</th>
        <th scope="col">Ações</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <tr>
        <!-- <th scope="row">1</th> -->
        <td style="width:30px;">
          <?php if($post['imagem']): ?>
          <img src="<?php echo e(asset('uploads/posts/'.$post->imagem)); ?>" width="80" height="80">
          <?php else: ?>
          <img src="<?php echo e(asset('padrao/padrao.jpeg')); ?>" width="80" height="80">
          <?php endif; ?>
        </td>
        <!-- <img src=<?php echo e(asset('uploads/posts/'.$post->imagem)); ?>></td> -->
        <td style="width:230px;"><a href="#"><?php echo e($post->titulo); ?></a></td>
        <td><?php echo e($post->descricao); ?></td>
        <td style="width:20px;">
          <a href="#"><i class="fa fa-pencil fa-lg" aria-hidden="true"></i></a>
          <a href="#"><i class="fa fa-times fa-lg" aria-hidden="true"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>